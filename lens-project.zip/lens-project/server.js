const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// ─────────────────────────────────────────────
// 功能 4：全域中間件 — 系統日誌監控
// 攔截所有請求，記錄時間、方法、路徑至 access.log
// ─────────────────────────────────────────────
app.use((req, res, next) => {
  const time = new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Taipei' });
  const log = `[${time}] ${req.method} ${req.url}\n`;

  // 同步寫入 access.log（appendFileSync 不會覆蓋舊紀錄）
  fs.appendFileSync(path.join(__dirname, 'access.log'), log, 'utf8');

  console.log(log.trim()); // 同時輸出到終端機方便除錯
  next();                  // 一定要呼叫 next()，讓請求繼續傳遞
});

// ─────────────────────────────────────────────
// 功能 1：靜態入口網頁 — Static Middleware
// 將 public/ 資料夾設為靜態資源根目錄
// 訪問 / 會自動回傳 public/index.html
// ─────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ─────────────────────────────────────────────
// 功能 2：動態產品查詢系統 — Route Parameters
// 路由：GET /product/:model.html
// ─────────────────────────────────────────────
app.get('/product/:model.html', (req, res) => {
  // 載入 JSON 資料，使用解構賦值取出 data 陣列
  const { data } = require('./data/lens.json');

  // 透過 req.params 取得 URL 上的型號參數
  const { model } = req.params;

  // 使用 Array.find() 在資料中搜尋對應產品
  const product = data.find((item) => item.model === model);

  if (product) {
    // 找到產品：用樣板字串動態產生完整 HTML 頁面
    const html = `
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${product.name} — Sony 展示中心</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #0a0a0a;
      color: #f0f0f0;
      min-height: 100vh;
    }
    header {
      padding: 20px 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #222;
    }
    .logo { font-size: 28px; font-weight: 700; letter-spacing: 4px; color: #fff; }
    nav a {
      color: #aaa; text-decoration: none; margin-left: 24px;
      font-size: 13px; letter-spacing: 1px; text-transform: uppercase;
    }
    nav a:hover { color: #fff; }
    .product-page {
      max-width: 960px;
      margin: 0 auto;
      padding: 80px 40px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 80px;
      align-items: center;
    }
    .product-img-wrap {
      background: #111;
      border: 1px solid #222;
      border-radius: 8px;
      overflow: hidden;
      aspect-ratio: 4/3;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .product-img-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .product-img-placeholder {
      font-size: 80px;
      color: #333;
    }
    .product-info { }
    .product-eyebrow {
      font-size: 11px;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: #555;
      margin-bottom: 16px;
    }
    .product-name-big {
      font-size: 42px;
      font-weight: 300;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 16px;
    }
    .product-model-tag {
      display: inline-block;
      background: #1a1a1a;
      border: 1px solid #333;
      color: #888;
      font-size: 12px;
      font-family: monospace;
      padding: 4px 12px;
      border-radius: 2px;
      margin-bottom: 24px;
      letter-spacing: 1px;
    }
    .product-desc {
      font-size: 15px;
      color: #666;
      line-height: 1.7;
      margin-bottom: 40px;
    }
    .back-link {
      display: inline-block;
      text-decoration: none;
      padding: 12px 28px;
      border: 1px solid #333;
      color: #aaa;
      font-size: 12px;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      border-radius: 2px;
      transition: all 0.2s;
    }
    .back-link:hover { border-color: #666; color: #fff; }
    @media (max-width: 640px) {
      .product-page { grid-template-columns: 1fr; gap: 40px; padding: 40px 20px; }
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">SONY</div>
    <nav>
      <a href="/">首頁</a>
      <a href="/admin">管理後台</a>
    </nav>
  </header>

  <div class="product-page">
    <div class="product-img-wrap">
      <img
        src="${product.imageUrl}"
        alt="${product.name}"
        onerror="this.style.display='none'; this.nextElementSibling.style.display='block'"
      />
      <div class="product-img-placeholder" style="display:none">📷</div>
    </div>

    <div class="product-info">
      <div class="product-eyebrow">Sony 相機展示中心</div>
      <div class="product-name-big">${product.name}</div>
      <div class="product-model-tag">型號：${product.model}</div>
      <div class="product-desc">${product.description}</div>
      <a href="/" class="back-link">← 返回首頁</a>
    </div>
  </div>
</body>
</html>`;

    res.status(200).send(html);
  } else {
    // 找不到產品：回傳 404
    res.status(404).send(`
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <title>404 找不到型號</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #0a0a0a; color: #f0f0f0;
      display: flex; align-items: center; justify-content: center; min-height: 100vh;
      flex-direction: column; gap: 16px;
    }
    h1 { font-size: 64px; font-weight: 300; color: #333; }
    p  { color: #555; font-size: 14px; }
    a  { color: #e0a040; text-decoration: none; font-size: 13px; letter-spacing: 1px; }
  </style>
</head>
<body>
  <h1>404</h1>
  <p>找不到型號：<strong style="color:#e0a040">${model}</strong></p>
  <a href="/">← 返回首頁</a>
</body>
</html>`);
  }
});

// ─────────────────────────────────────────────
// 功能 3：安全性管理後台 — Route Authorization
// 路由：GET /admin
// 驗證 Query String：?code=521
// ─────────────────────────────────────────────
app.get('/admin', (req, res) => {
  // 從 URL 查詢字串取得 code 參數
  const { code } = req.query;

  if (code === '521') {
    // 驗證成功：200 OK
    res.status(200).send(`
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <title>管理後台</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #0a0a0a; color: #f0f0f0;
      display: flex; align-items: center; justify-content: center; min-height: 100vh;
      flex-direction: column; gap: 12px;
    }
    .badge {
      background: #0f2; color: #000;
      font-size: 11px; letter-spacing: 2px; padding: 4px 12px; border-radius: 99px;
      text-transform: uppercase; font-weight: 600;
    }
    h1 { font-size: 36px; font-weight: 300; }
    p  { color: #555; font-size: 14px; }
    a  { color: #e0a040; text-decoration: none; font-size: 13px; letter-spacing: 1px; }
  </style>
</head>
<body>
  <div class="badge">✓ Authorized</div>
  <h1>Welcome to Admin</h1>
  <p>歡迎進入後台　— 授權碼驗證成功</p>
  <a href="/">← 返回首頁</a>
</body>
</html>`);
  } else {
    // 驗證失敗：403 Forbidden
    res.status(403).send(`
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <title>Access Denied</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #0a0a0a; color: #f0f0f0;
      display: flex; align-items: center; justify-content: center; min-height: 100vh;
      flex-direction: column; gap: 12px;
    }
    .badge {
      background: #c00; color: #fff;
      font-size: 11px; letter-spacing: 2px; padding: 4px 12px; border-radius: 99px;
      text-transform: uppercase; font-weight: 600;
    }
    h1 { font-size: 36px; font-weight: 300; }
    p  { color: #555; font-size: 14px; }
    a  { color: #e0a040; text-decoration: none; font-size: 13px; letter-spacing: 1px; }
  </style>
</head>
<body>
  <div class="badge">403 Forbidden</div>
  <h1>Access Denied</h1>
  <p>暗號錯誤，請確認授權碼後再試</p>
  <a href="/">← 返回首頁</a>
</body>
</html>`);
  }
});

// ─────────────────────────────────────────────
// 功能 5：萬用防呆路由 — Wildcard Route
// 必須放在所有路由的最下方
// 處理所有未定義的路徑，回傳 404
// ─────────────────────────────────────────────
app.all(/.*$/, (req, res) => {
  res.status(404).send(`
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <title>404 Not Found</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #0a0a0a; color: #f0f0f0;
      display: flex; align-items: center; justify-content: center; min-height: 100vh;
    }
    .container { text-align: center; }
    .big404 {
      font-size: 140px;
      font-weight: 700;
      line-height: 1;
      color: #1a1a1a;
      letter-spacing: -4px;
      margin-bottom: 8px;
    }
    h2 { font-size: 22px; font-weight: 300; color: #555; margin-bottom: 12px; }
    p  { font-size: 14px; color: #444; margin-bottom: 32px; }
    a {
      display: inline-block;
      text-decoration: none;
      padding: 12px 28px;
      border: 1px solid #333;
      color: #aaa;
      font-size: 12px;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      border-radius: 2px;
      transition: all 0.2s;
    }
    a:hover { border-color: #666; color: #fff; }
  </style>
</head>
<body>
  <div class="container">
    <div class="big404">404</div>
    <h2>Not Found</h2>
    <p>抱歉，路徑不存在：<code style="color:#e0a040">${req.url}</code></p>
    <a href="/">← 返回首頁</a>
  </div>
</body>
</html>`);
});

// ─────────────────────────────────────────────
// 啟動伺服器
// ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 伺服器已啟動！`);
  console.log(`   本機網址：http://localhost:${PORT}`);
  console.log(`   產品頁面：http://localhost:${PORT}/product/Alpha6700.html`);
  console.log(`   管理後台：http://localhost:${PORT}/admin?code=521\n`);
});
